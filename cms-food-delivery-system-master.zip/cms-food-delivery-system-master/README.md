# cms-food-delivery-system
Its a CMS developed by codeigniter/Javascript/Jquery framework. Its a part of a food delivery system Android app. Client,Restaurant,Comapny, delivery boys and reporting can be created and managed by this cms. And the delivery process based on geolocation are done by Android App. 
