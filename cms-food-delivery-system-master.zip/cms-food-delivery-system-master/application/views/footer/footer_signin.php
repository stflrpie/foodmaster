<!-- footer -->
  <footer id="footer">
    <div class="text-center padder clearfix">
      <p>
        <small>&copy; first 2013, Mobile first web app framework base on Bootstrap</small><br><br>
        <a href="#" class="btn btn-xs btn-circle btn-twitter"><i class="fa fa-twitter"></i></a>
        <a href="#" class="btn btn-xs btn-circle btn-facebook"><i class="fa fa-facebook"></i></a>
        <a href="#" class="btn btn-xs btn-circle btn-gplus"><i class="fa fa-google-plus"></i></a>
      </p>
    </div>
  </footer>
  <!-- / footer -->
	<script src="<?php echo base_url();?>static/js/jquery.min.js"></script>
  <!-- Bootstrap -->
  <script src="<?php echo base_url();?>static/js/bootstrap.js"></script>
  <!-- app -->
  <script src="<?php echo base_url();?>static/js/app.js"></script>
  <script src="<?php echo base_url();?>static/js/app.plugin.js"></script>
  <script src="<?php echo base_url();?>static/js/app.data.js"></script>
</body>
</html>