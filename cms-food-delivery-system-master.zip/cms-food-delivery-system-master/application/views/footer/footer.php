<!-- footer -->
  <footer id="footer">
    <div class="text-center padder clearfix">
      <p>
        <small>&copy; first 2013, Mobile first web app framework base on Bootstrap</small><br><br>
        <a href="#" class="btn btn-xs btn-circle btn-twitter"><i class="fa fa-twitter"></i></a>
        <a href="#" class="btn btn-xs btn-circle btn-facebook"><i class="fa fa-facebook"></i></a>
        <a href="#" class="btn btn-xs btn-circle btn-gplus"><i class="fa fa-google-plus"></i></a>
      </p>
    </div>
  </footer>
  <a href="#" class="hide slide-nav-block" data-toggle="class:slide-nav slide-nav-left" data-target="body"></a>
  <!-- / footer -->
	<script src="<?php echo base_url();?>static/js/jquery.min.js"></script>
  <!-- Bootstrap -->
  <script src="<?php echo base_url();?>static/js/bootstrap.js"></script>
  <!-- app -->
  <script src="<?php echo base_url();?>static/js/app.js"></script>
  <script src="<?php echo base_url();?>static/js/app.plugin.js"></script>
  <script src="<?php echo base_url();?>static/js/app.data.js"></script>

  <!-- Sparkline Chart -->
  <script src="<?php echo base_url();?>static/js/charts/sparkline/jquery.sparkline.min.js"></script>  
  <!-- Easy Pie Chart -->
  <script src="<?php echo base_url();?>static/js/charts/easypiechart/jquery.easy-pie-chart.js"></script>  
  
  <script src="<?php echo base_url();?>static/js/fuelux/fuelux.js"></script>
  <!-- datepicker -->
  <script src="<?php echo base_url();?>static/js/datepicker/bootstrap-datepicker.js"></script>
  <!-- slider -->
  <script src="<?php echo base_url();?>static/js/slider/bootstrap-slider.js"></script>
  <!-- file input -->  
  <script src="<?php echo base_url();?>static/js/file-input/bootstrap.file-input.js"></script>
  <!-- combodate -->
  <script src="<?php echo base_url();?>static/js/combodate/moment.min.js"></script>
  <script src="<?php echo base_url();?>static/js/combodate/combodate.js"></script>
  <!-- parsley -->
  <script src="<?php echo base_url();?>static/js/parsley/parsley.min.js"></script>
  <!-- select2 -->
  <script src="<?php echo base_url();?>static/js/select2/select2.min.js"></script>
  <script src="<?php echo base_url();?>static/js/script_ss.js"></script>
  
</body>
</html>